class CinPanelPopup {
    constructor() {
        this.tokenInp = document.getElementById('accessToken');
        this.urlInp = document.getElementById('apiUrl');
        this.pageSel = document.getElementById('pageNumber');
        this.fastBtn = document.getElementById('fastBtn');
        this.singleBtn = document.getElementById('singleBtn');
        this.stopBtn = document.getElementById('stopBtn');
        this.statusDiv = document.getElementById('status');
        this.init();
    }
    async init() {
        await this.load();
        this.fastBtn.addEventListener('click', () => this.fill('fast'));
        this.singleBtn.addEventListener('click', () => this.fill('single'));
        this.stopBtn.addEventListener('click', () => this.stop());
        this.tokenInp.addEventListener('input', () => this.save());
        this.urlInp.addEventListener('input', () => this.save());
        this.pageSel.addEventListener('change', () => this.save());
        this.checkPage();
    }
    async load() {
        try {
            const r = await chrome.storage.local.get(['lastToken', 'lastApiUrl', 'lastPage']);
            if (r.lastToken) this.tokenInp.value = r.lastToken;
            if (r.lastApiUrl) this.urlInp.value = r.lastApiUrl;
            if (r.lastPage) this.pageSel.value = r.lastPage;
        } catch(e) {}
    }
    async save() {
        try {
            await chrome.storage.local.set({
                lastToken: this.tokenInp.value.trim(),
                lastApiUrl: this.urlInp.value.trim(),
                lastPage: this.pageSel.value
            });
        } catch(e) {}
    }
    async checkPage() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.url.includes('consular.mfa.gov.cn')) {
                this.show('Cin vize sayfasinda degilsiniz', 'error');
                this.fastBtn.disabled = true;
                this.singleBtn.disabled = true;
            }
        } catch(e) {}
    }
    async fill(mode) {
        const token = this.tokenInp.value.trim();
        const url = this.urlInp.value.trim();
        const page = parseInt(this.pageSel.value);
        if (!token) { this.show('Token girin', 'error'); return; }
        if (!url) { this.show('API URL girin', 'error'); return; }

        this.setLoading(true);
        this.stopBtn.style.display = 'block';

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            try {
                await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
            } catch(e) {}
            await new Promise(r => setTimeout(r, 300));

            const response = await chrome.tabs.sendMessage(tab.id, {
                action: 'fillFormWithToken',
                token, apiUrl: url, pageNumber: page, mode
            });

            if (response?.success) {
                this.show(mode === 'fast' ? 'Tum sayfalar dolduruldu!' : 'Sayfa ' + page + ' dolduruldu!', 'success');
                await this.save();
            } else {
                throw new Error(response?.error || 'Hata');
            }
        } catch(e) {
            if (!e.message.includes('Durduruldu')) {
                this.show('Hata: ' + e.message, 'error');
            }
        } finally {
            this.setLoading(false);
            this.stopBtn.style.display = 'none';
        }
    }
    async stop() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            await chrome.tabs.sendMessage(tab.id, { action: 'stopFilling' });
            this.show('Durduruldu!', 'error');
            this.setLoading(false);
            this.stopBtn.style.display = 'none';
        } catch(e) {}
    }
    setLoading(v) {
        this.fastBtn.disabled = v;
        this.singleBtn.disabled = v;
        this.tokenInp.disabled = v;
        this.urlInp.disabled = v;
        this.pageSel.disabled = v;
        if (v) {
            this.fastBtn.innerHTML = '<span class="spinner"></span>Calisiyor...';
            this.singleBtn.innerHTML = '<span class="spinner"></span>Calisiyor...';
        } else {
            this.fastBtn.textContent = 'Hizli Doldur';
            this.singleBtn.textContent = 'Bu Sayfayi Doldur';
        }
    }
    show(msg, type) {
        this.statusDiv.textContent = msg;
        this.statusDiv.className = 'status ' + type;
        this.statusDiv.style.display = 'block';
        setTimeout(() => { this.statusDiv.style.display = 'none'; }, 5000);
    }
}
document.addEventListener('DOMContentLoaded', () => new CinPanelPopup());